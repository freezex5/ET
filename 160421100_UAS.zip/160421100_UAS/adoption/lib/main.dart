import 'package:adoption/screen/adopt.dart';
import 'package:adoption/screen/browse.dart';
import 'package:adoption/screen/login.dart';
import 'package:adoption/screen/offer.dart';
import 'package:adoption/screen/register.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

String active_user = "";
String _username = "";

void doLogout() async {
  final prefs = await SharedPreferences.getInstance();
  active_user = "";
  await prefs.remove("user_id");
  await prefs.remove("user_name");
  await prefs.remove("user_password");

  main();
}

Future<String> checkUser() async {
  final prefs = await SharedPreferences.getInstance();
  String user_id = prefs.getString("user_id") ?? '';
  return user_id;
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  checkUser().then((String result) {
    if (result == '') {
      runApp(MaterialApp(home: Login()));
    } else {
      active_user = result;
      runApp(MyApp());
    }
  });
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        'browse': (context) => Browse(),
        'offer': (context) => Offer(),
        'adopt': (context) => Adopt(),
        'login': (context) => Login(),
        'register': (context) => Register()
      },
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _loadUserName();
  }

  _loadUserName() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _username = prefs.getString("user_name") ?? "Guest";
    });
  }

  final List<Widget> _screens = [Browse(), Offer(), Adopt()];
  final List<String> _judul = ['Browse', 'Offer', 'Adopt'];

  @override
  Widget build(BuildContext context) {
    var scaffold = Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(_judul[_currentIndex]),
      ),
      body: _screens[_currentIndex],
      drawer: methodDrawer(),
      bottomNavigationBar: methodBottomNavBar(),
    );
    return scaffold;
  }

  BottomNavigationBar methodBottomNavBar() {
    return BottomNavigationBar(
        currentIndex: _currentIndex,
        unselectedItemColor: Colors.grey,
        fixedColor: Colors.teal,
        items: [
          BottomNavigationBarItem(
            label: "Browse",
            icon: Icon(
              Icons.search,
              size: 40,
            ),
          ),
          BottomNavigationBarItem(
            label: "Offer",
            icon: Icon(
              Icons.local_offer,
              size: 40,
            ),
          ),
          BottomNavigationBarItem(
            label: "Adopt",
            icon: Icon(
              Icons.pets,
              size: 40,
            ),
          )
        ],
        onTap: (int index) {
          setState(() {
            _currentIndex = index;
          });
        });
  }

  Drawer methodDrawer() {
    return Drawer(
      elevation: 16.0,
      child: Column(
        children: <Widget>[
          UserAccountsDrawerHeader(
            accountName: Text(_username),
            accountEmail: Text(active_user),
            currentAccountPicture: CircleAvatar(
                backgroundImage: NetworkImage("https://i.pravatar.cc/150")),
          ),
          Divider(height: 20.0),
          ListTile(
            title: Text(active_user != "" ? "Logout" : "Login"),
            leading: Icon(Icons.login),
            onTap: () {
              active_user != ""
                  ? doLogout()
                  : Navigator.popAndPushNamed(context, 'login');
            },
          ),
        ],
      ),
    );
  }
}