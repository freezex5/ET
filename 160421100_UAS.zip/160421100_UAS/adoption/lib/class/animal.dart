class Animal {
  final String name;
  final String species;
  final String description;
  final String imageUrl;

  Animal({
    required this.name,
    required this.species,
    required this.description,
    required this.imageUrl,
  });
}
