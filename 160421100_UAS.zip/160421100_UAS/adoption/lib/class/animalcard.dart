import 'package:adoption/class/animal.dart';
import 'package:adoption/screen/propose.dart';
import 'package:flutter/material.dart';

class AnimalCard extends StatelessWidget {
  final Animal animal;

  const AnimalCard({super.key, required this.animal});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: <Widget>[
          Image.network(animal.imageUrl),
          ListTile(
            title: Text(animal.name),
            subtitle: Text(animal.species),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(animal.description),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Propose(animal: animal),
                ),
              );
            },
            child: const Text('Propose to Adopt'),
          ),
        ],
      ),
    );
  }
}
