import 'package:flutter/material.dart';

class Decision extends StatelessWidget {
  const Decision({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> applicants = [
      {'name': 'Alice', 'reason': 'Loves dogs'},
      {'name': 'Bob', 'reason': 'Has a big yard'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Choose Adopter'),
      ),
      body: ListView.builder(
        itemCount: applicants.length,
        itemBuilder: (context, index) {
          final applicant = applicants[index];
          return Card(
            child: ListTile(
              title: Text(applicant['name']!),
              subtitle: Text(applicant['reason']!),
              trailing: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Choose'),
              ),
            ),
          );
        },
      ),
    );
  }
}
