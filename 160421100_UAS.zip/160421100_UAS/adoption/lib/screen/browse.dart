import 'package:adoption/class/animal.dart';
import 'package:adoption/screen/propose.dart';
import 'package:flutter/material.dart';


class Browse extends StatelessWidget {
  const Browse({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Animal> animals = [
      Animal(
        name: 'Buddy',
        species: 'Dog',
        description: 'A friendly dog',
        imageUrl: 'https://example.com/buddy.jpg',
      ),
      Animal(
        name: 'Mittens',
        species: 'Cat',
        description: 'A cute cat',
        imageUrl: 'https://example.com/mittens.jpg',
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Browse Animals'),
      ),
      body: ListView.builder(
        itemCount: animals.length,
        itemBuilder: (context, index) {
          final animal = animals[index];
          return Card(
            child: ListTile(
              leading: CircleAvatar(child: Text(animal.name[0])),
              title: Text(animal.name),
              subtitle: Text(animal.description),
              trailing: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => Propose(animal: animal),
                    ),
                  );
                },
                child: const Text('Propose'),
              ),
            ),
          );
        },
      ),
    );
  }
}
