import 'package:adoption/class/animal.dart';
import 'package:flutter/material.dart';

class Propose extends StatelessWidget {
  final Animal animal;

  const Propose({super.key, required this.animal});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Propose to Adopt ${animal.name}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            Image.network(animal.imageUrl),
            const SizedBox(height: 16),
            Text(
              animal.description,
              style: Theme.of(context).textTheme.bodyText1,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                // Implement propose adoption logic here
              },
              child: const Text('Submit Proposal'),
            ),
          ],
        ),
      ),
    );
  }
}
