import 'package:adoption/screen/decision.dart';
import 'package:adoption/screen/newoffer.dart';
import 'package:flutter/material.dart';

class Offer extends StatelessWidget {
  const Offer({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> offers = [
      {'name': 'Buddy', 'status': 'Adopted', 'adopter': 'Alice'},
      {'name': 'Mittens', 'status': 'Pending', 'interested': 2},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Offers'),
      ),
      body: ListView.builder(
        itemCount: offers.length,
        itemBuilder: (context, index) {
          final offer = offers[index];
          return Card(
            child: ListTile(
              leading: CircleAvatar(child: Text(offer['name']![0])),
              title: Text(offer['name']!),
              subtitle: Text('Status: ${offer['status']}'),
              trailing: offer['status'] == 'Pending'
                  ? ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const Decision(),
                          ),
                        );
                      },
                      child: const Text('Choose Adopter'),
                    )
                  : Text('Adopted by: ${offer['adopter']}'),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const NewOffer()),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
