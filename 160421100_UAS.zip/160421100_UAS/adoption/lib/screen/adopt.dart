import 'package:flutter/material.dart';

class Adopt extends StatelessWidget {
  const Adopt({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> adoptions = [
      {'name': 'Buddy', 'status': 'Adopted'},
      {'name': 'Mittens', 'status': 'Pending'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Adoptions'),
      ),
      body: ListView.builder(
        itemCount: adoptions.length,
        itemBuilder: (context, index) {
          final adoption = adoptions[index];
          return Card(
            child: ListTile(
              leading: CircleAvatar(child: Text(adoption['name']![0])),
              title: Text(adoption['name']!),
              subtitle: Text('Status: ${adoption['status']}'),
            ),
          );
        },
      ),
    );
  }
}
